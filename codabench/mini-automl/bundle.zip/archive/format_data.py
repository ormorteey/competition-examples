import pandas as pd

DATA_FILE = 'wine.csv'
NAME = DATA_FILE.split('.')[0]
Y_COLUMN = 'quality' # column to separate as the class

def label(data, column):
    """ Performs label encoding.
        Example:
            Color: ['blue', 'green', 'blue', 'pink']
            is encoded by
            Color: [1, 2, 1, 3]
        :param data: Data
        :param column: Column to encode
        :return: Encoded data
        :rtype: pd.DataFrame
    """
    data[column] = data[column].astype('category').cat.codes
    return data

def encode(data):
    categorical_columns = data.columns[data.dtypes==object].tolist()
    for column in categorical_columns:
        data = label(data, column)
    return data

def split(data):
    # train test split
    i = int(data.shape[0] * (2/5))
    return data.iloc[:i], data.iloc[i:]

def x_y(data, y_column):
    # separate class and data
    # class is a column name
    y = data[y_column]
    x = data.drop(columns=[y_column], axis=1)
    return x, y

def shuffle(data):
    return data.sample(frac=1).reset_index(drop=True)

# Read
data = pd.read_csv(DATA_FILE)
data = data.dropna()
data = shuffle(data)
# If needed
#data = data.drop(columns=['ID'], axis=1)
# Format
data = encode(data)
train, test = split(data)
x_train, y_train = x_y(train, Y_COLUMN)
x_test, y_test = x_y(test, Y_COLUMN)
# Save
x_train.to_csv(NAME + '_input_train.csv', index=False)
y_train.to_csv(NAME + '_reference_train.csv', index=False)
x_test.to_csv(NAME + '_input_test.csv', index=False)
y_test.to_csv(NAME + '_reference_test.csv', index=False)
