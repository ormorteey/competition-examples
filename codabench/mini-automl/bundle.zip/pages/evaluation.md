# Evaluation

For each dataset, the model is initialized and trained from scratch.

The scoring metric used is the [accuracy score](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.accuracy_score.html).
