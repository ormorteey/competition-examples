# Data

|Phase|Nickname|Task|
|---|---|---|
| Feedback | dataset1 | Classification |
| Feedback | dataset2 | Classification |
| Feedback | dataset3 | Classification |
| Feedback | dataset4 | Classification |
| Final | dataset1 | Classification |
| Final | dataset2 | Classification |
| Final | dataset3 | Classification |
| Final | dataset4 | Classification |
