# Mini-AutoML Benchmark

Mini-AutoML is a benchmark template for Codabench, featuring code submission to multiple datasets.
This benchmark involves two phases:
- Feedback phase, with 4 datasets,
- Final phase, with 4 different datasets.

All tasks are **classification tasks**.

Made by [Adrien Pavao](https://adrienpavao.com/).
